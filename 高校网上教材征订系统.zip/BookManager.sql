/*
SQLyog Community Edition- MySQL GUI v6.07
Host - 5.0.11-beta-nt : Database - BookManager
*********************************************************************
Server version : 5.0.11-beta-nt
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

create database if not exists `BookManager`;

USE `BookManager`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Data for the table `administor` */

insert  into `administor`(`id`,`password`,`mark`) values ('123','321','0');

/*Data for the table `book` */

insert  into `book`(`book_id`,`author`,`name`,`type`,`price`,`publisher`,`pubDate`,`introduce`,`quantity`) values ('1','lihua','uml','教材',10,'uestc','200903','《UML精粹：标准对象建模语言简明指南（第3版）》适合作为计算机、电子、通信等专业本科及研究生课程教材，对软件开发人员及专业研究者也极具参考价值。',300),('2','wangyi','rational','soft',20,'uestc','200801',NULL,45),('3','lihua','语音','soft',30,'uestc','200911',NULL,65),('4','liu','shuxue','soft',30,'uestc','200502',NULL,30),('5','张三','语文','soft',20,'电子科技大学','200302',NULL,342),('6','李四','数学','软件',56,'电子科技大学','201001',NULL,444),('7','王五','英语','教材',46,'清华大学','201102',NULL,6);

/*Data for the table `book_comment` */

insert  into `book_comment`(`book_com_id`,`book_id`,`com_id`) values (1,'1',2),(2,'1',1),(3,'1',3),(4,'1',4),(5,'1',5);

/*Data for the table `comment` */

insert  into `comment`(`com_id`,`comment`) values (1,'ddddd'),(2,'dddd'),(3,'dddas'),(4,'大大大、'),(5,'jaioje的');

/*Data for the table `orders` */

/*Data for the table `plan` */

insert  into `plan`(`plan_id`,`book_id`,`tea_id`,`number`,`book_name`,`tea_name`,`price`) values (5,'1','123456',0,'uml','lihua',10);

/*Data for the table `stu_book` */

insert  into `stu_book`(`stu_book_id`,`stu_id`,`book_id`,`term`,`term1`) values (1,'2011223040006','1',2013,2014),(2,'2011223040006','2',2013,2014),(3,'2011223040006','3',2013,2014),(4,'2011223040006','4',2013,2014);

/*Data for the table `student` */

insert  into `student`(`id`,`username`,`password`,`mark`) values ('2011223040006','liumeng','123456',2);

/*Data for the table `tea_book` */

insert  into `tea_book`(`tea_book_id`,`tea_id`,`book_id`,`term`,`term1`) values (1,'123456','1',2013,2014),(2,'123456','2',2013,2014),(3,'123456','3',2013,2014),(4,'123456','4',2013,2014);

/*Data for the table `teacher` */

insert  into `teacher`(`id`,`username`,`password`,`tel`,`email`,`mark`) values ('123456','lihua','123456',NULL,NULL,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
