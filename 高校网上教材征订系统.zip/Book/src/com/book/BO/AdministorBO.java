package com.book.BO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.bean.Book;
import com.book.bean.Comment;
import com.book.util.DBConn;
public class AdministorBO {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement ps;
	public void updatePassword(String username, String pwd, String newpwd) {
		con = DBConn.getConn();
		try {
			 st = con.createStatement();
			 st.execute("update administor set id='"+username+"',password='"+newpwd+"' where password ='"+pwd+"'");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}		
	}
	public List<Comment> allComment(String bookId) {
		List<Comment> list =new ArrayList<Comment>();
		con = DBConn.getConn();
		ResultSet rd = null;
		try {
			 st = con.createStatement();
			 rs=st.executeQuery("select * from book_comment where book_id='"+bookId+"'");
			 while(rs.next()){
				 String com_id =rs.getString(3);
				  ps = con.prepareStatement("select * from comment where com_id='"+com_id+"'");
	              rd = ps.executeQuery();
				 //rd=st.executeQuery("select * from comment where com_id='"+com_id+"'");
				 while(rd.next()){
					 Comment p = new Comment(rd.getString(1),rd.getString(2));
						list.add(p);  
				 }				 	
			 }
			 ps.close();
			 rd.close();
			 
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}		
		return list;
	}

}
