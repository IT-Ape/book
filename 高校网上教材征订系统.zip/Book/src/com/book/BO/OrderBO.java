package com.book.BO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.bean.*;
import com.book.util.DBConn;
public class OrderBO {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement ps;
	public int addOrders(String planId) {
		con = DBConn.getConn();
		int a=0;
		try {
			 ps = con.prepareStatement("insert into orders(plan_id) values ('"+planId+"')");
		   	 ps.execute();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public List<Plan> AllOrders() {
		con = DBConn.getConn();
		List<Plan> list =new ArrayList<Plan>() ;
		String plan_id =null;
		ResultSet rd = null;
		try {
 		 st = con.createStatement();
	     rs = st.executeQuery("select * from orders where desoft!=0");
	     
	     while(rs.next()){
	    	 plan_id =rs.getString(2);
	    	 ps = con.prepareStatement("select * from plan where plan_id='"+plan_id+"'");
             rd = ps.executeQuery();
             while(rd.next()){
              Plan p = new Plan(rd.getString(2),rd.getString(1),rd.getString(3),rd.getString(5),rd.getString(6),rd.getDouble(7),rd.getInt(4));
   			  list.add(p);    
             }
		}
	     rd.close();
	     ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return list;
	}

	
	
}
