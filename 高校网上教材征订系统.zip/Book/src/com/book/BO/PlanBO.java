package com.book.BO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.bean.*;
import com.book.util.DBConn;
public class PlanBO {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement ps;
	public int addplan(String id, String id2) {
		con = DBConn.getConn();
		int a=0;
		try {
			 ps = con.prepareStatement("insert into plan(tea_id,book_id) values ('"+id+"','"+id2+"')");
		   	 ps.execute();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public List<Book> findAllBook(String id) {
		// TODO Auto-generated method stub
		con = DBConn.getConn();
		ResultSet rd = null;
		List<Book> list =new ArrayList<Book>() ;
		try {
 		 st = con.createStatement();
	     rs = st.executeQuery("select * from plan where tea_id='"+id+"'");
	     while(rs.next()){
			   String book_id = rs.getString(2);
			   ps = con.prepareStatement("select * from book where book_id='"+book_id+"'");
               rd = ps.executeQuery();
               while(rd.next()){
            	   Book p = new Book(rd.getString(1),rd.getString(2),rd.getString(3),rd.getString(4),
							rd.getDouble(5),rd.getString(6),rd.getString(7),rd.getString(8));
					list.add(p);            	   
               }
			}
	     ps.close();
	     rd.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return list;
	}
	public int addplanNumber(String id, String id2, String number) {
		con = DBConn.getConn();
		int a=0;
		try {
			 ps = con.prepareStatement("update plan set number='"+number+"' where tea_id ='"+id+"' and book_id='"+id2+"'");
		   	 ps.execute();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public int movePlan(String id, String id2) {
		con = DBConn.getConn();
		int a=0;
		try {
			 ps = con.prepareStatement("delete from plan where tea_id ='"+id+"' and book_id='"+id2+"'");
		   	 ps.execute();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public int searchAll() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public List<Plan> AllBookPlan() {
		con = DBConn.getConn();
		List<Plan> list =new ArrayList<Plan>() ;
		try {
 		 st = con.createStatement();
	     rs = st.executeQuery("select * from plan where number!=0");
	     while(rs.next()){
              Plan p = new Plan(rs.getString(2),rs.getString(1),rs.getString(3),rs.getString(5),rs.getString(6),rs.getInt(4));
			  list.add(p);            	   
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return list;
	}
	public int movePlan(String id) {
		con = DBConn.getConn();
		PreparedStatement pd;
		int a=0;
		try {
			 pd = con.prepareStatement("delete from orders where plan_id='"+id+"'");
		   	 pd.execute();
			 ps = con.prepareStatement("delete from plan where plan_id='"+id+"'");
		   	 ps.execute();
		   	 pd.close();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public int addplan(String id, String username, String id2, String bookName) {
		con = DBConn.getConn();
		int a=0;
		try {
			 ps = con.prepareStatement("insert into plan(tea_id,tea_name,book_id,book_name) " +
			 		"values ('"+id+"','"+username+"','"+id2+"','"+bookName+"')");
		   	 ps.execute();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public int addplan(String bookId, String number, String bookName) {
		con = DBConn.getConn();
		PreparedStatement pd;
		int a=0;
		String plan_id =null;
		try {
			 ps = con.prepareStatement("insert into plan(book_id,number,book_name) " +
			 		"values ('"+bookId+"','"+number+"','"+bookName+"')");
		   	 ps.execute();
		   	 st = con.createStatement();
		     rs = st.executeQuery("select plan_id from plan where book_id='"+bookId+"' and number ='"+number+"'");
		     while(rs.next()){
	             plan_id = rs.getString(1);           	   
				}
		     System.out.println(plan_id);
		   	 pd = con.prepareStatement("insert into orders(plan_id) values ('"+plan_id+"')");
			 pd.execute();
		   	 pd.close();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public int addplan(String id, String username, String id2, String bookName,
			double price) {
		con = DBConn.getConn();
		int a=0;
		try {
			 ps = con.prepareStatement("insert into plan(tea_id,tea_name,book_id,book_name,price) " +
			 		"values ('"+id+"','"+username+"','"+id2+"','"+bookName+"','"+price+"')");
		   	 ps.execute();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}
	public int addplan1(String bookId, String number, String bookName,
			double price) {
		con = DBConn.getConn();
		PreparedStatement pd;
		int a=0;
		String plan_id =null;
		try {
			 ps = con.prepareStatement("insert into plan(book_id,number,book_name,price) values ('"+bookId+"','"+number+"','"+bookName+"','"+price+"')");
		   	 ps.execute();
		   	 st = con.createStatement();
		     rs = st.executeQuery("select plan_id from plan where book_id='"+bookId+"' and number ='"+number+"'");
		     while(rs.next()){
	             plan_id = rs.getString(1);           	   
				}
		     System.out.println(plan_id);
		   	 pd = con.prepareStatement("insert into orders(plan_id) values ('"+plan_id+"')");
			 pd.execute();
		   	 pd.close();
		   	 ps.close();
		   	 a=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
	}


}
