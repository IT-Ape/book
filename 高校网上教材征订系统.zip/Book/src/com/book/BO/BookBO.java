package com.book.BO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.bean.Book;
import com.book.bean.Plan;
import com.book.bean.Student;
import com.book.util.DBConn;

public class BookBO {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement ps;
	public List<Book> findBookByName(String value) {
		List<Book> list =new ArrayList<Book>();
		con = DBConn.getConn();
		
		char s2[] = value.toCharArray();
		try {
			ps = con.prepareStatement("select * from book");
			rs = ps.executeQuery();
			//���������
			while(rs.next()){
				int flag = 0;
				String s = rs.getString("name");
				if(value.equals(s)){
					Book p = new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
							rs.getDouble(5),rs.getString(6),rs.getString(7),rs.getString(8));
				    list.add(p);
				}else{
					char s1[] = s.toCharArray();
					for(int i=0;i<s2.length;i++){
						for(int j = 0;j<s1.length;j++){
							if(s1[j]==s2[i]){
								flag++;
							}
						}
					}
					if(flag==s2.length){
						Book p = new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
								rs.getDouble(5),rs.getString(6),rs.getString(7),rs.getString(8));
						list.add(p);
					}
				}
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, ps, con);
		}
		return list;
	}
	public List<Book> findBookByID(String value) {
		List<Book> list =new ArrayList<Book>();
		con = DBConn.getConn();
		char s2[] = value.toCharArray();
		try {	
		ps = con.prepareStatement("select * from book");
		rs = ps.executeQuery();
		//���������
		while(rs.next()){
			int flag = 0;
			String s = rs.getString("book_id");
			if(value.equals(s)){
				Book p = new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
						rs.getDouble(5),rs.getString(6),rs.getString(7),rs.getString(8));
			      list.add(p);
			}else{
				char s1[] = s.toCharArray();
				for(int i=0;i<s2.length;i++){
					for(int j = 0;j<s1.length;j++){
						if(s1[j]==s2[i]){
							flag++;
						}
					}
				}
				if(flag==s2.length){
					Book p = new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
							rs.getDouble(5),rs.getString(6),rs.getString(7),rs.getString(8));
					list.add(p);
				}
			}
			
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		DBConn.close(rs, ps, con);
	}
	return list;
	}
	public List<Book> findBookByAuthor(String value) {
		List<Book> list =new ArrayList<Book>();
		con = DBConn.getConn();
		
		char s2[] = value.toCharArray();
		try {
			ps = con.prepareStatement("select * from book");
			rs = ps.executeQuery();
			//���������
			while(rs.next()){
				int flag = 0;
				String s = rs.getString("author");
				if(value.equals(s)){
					Book p = new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
							rs.getDouble(5),rs.getString(6),rs.getString(7),rs.getString(8));
				    list.add(p);
				}else{
					char s1[] = s.toCharArray();
					for(int i=0;i<s2.length;i++){
						for(int j = 0;j<s1.length;j++){
							if(s1[j]==s2[i]){
								flag++;
							}
						}
					}
					if(flag==s2.length){
						Book p = new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
								rs.getDouble(5),rs.getString(6),rs.getString(7),rs.getString(8));
						list.add(p);
					}
				}
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, ps, con);
		}
		return list;
	}
	public int updateComment(String id,String comment) {
		con = DBConn.getConn();
		int a=0;
		try {
			 ps = con.prepareStatement("insert into comment(comment) values ('"+comment+"')");
			 ps.execute();
			 st = con.createStatement();
			 rs = st.executeQuery("select * from comment where comment='"+comment+"'");
			 if(rs.next()){
		      ps = con.prepareStatement("insert into book_comment(book_id,com_id) values ('"+id+"','"+rs.getInt(1)+"')");
			  ps.execute();
			  a=1;
			 }
			 ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return a;
		
	}
	public List<Book> findBookByYear(String id, int year, int year1) {
		List<Book> list =new ArrayList<Book>();
		ResultSet rd = null;
		con = DBConn.getConn();
		try {
			ps = con.prepareStatement("select book_id from stu_book where stu_id='"+id+"'" +
					                    "and term='"+year+"' and term1='"+year1+"'");
			rs = ps.executeQuery();
			while(rs.next()){
			   String book_id = rs.getString(1);
			   ps = con.prepareStatement("select * from book where book_id='"+book_id+"'");
               rd = ps.executeQuery();
               while(rd.next()){
            	   Book p = new Book(rd.getString(1),rd.getString(2),rd.getString(3),rd.getString(4),
							rd.getDouble(5),rd.getString(6),rd.getString(7),rd.getString(8));
					list.add(p);            	   
               }
			}
			rd.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, ps, con);
		}
		return list;
	}
	public List<Book> findBookByTYear(String id, int year, int year1) {
		List<Book> list =new ArrayList<Book>();
		ResultSet rd = null;
		con = DBConn.getConn();
		try {
			ps = con.prepareStatement("select book_id from tea_book where tea_id='"+id+"'" +
					                    "and term='"+year+"' and term1='"+year1+"'");
			rs = ps.executeQuery();
			while(rs.next()){
			   String book_id = rs.getString(1);
			   ps = con.prepareStatement("select * from book where book_id='"+book_id+"'");
               rd = ps.executeQuery();
               while(rd.next()){
            	   Book p = new Book(rd.getString(1),rd.getString(2),rd.getString(3),rd.getString(4),
							rd.getDouble(5),rd.getString(6),rd.getString(7),rd.getString(8));
					list.add(p);            	   
               }
			}
			rd.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, ps, con);
		}
		return list;
	}
	public List<Book> searchAllBook() {
		con = DBConn.getConn();
		List<Book> list =new ArrayList<Book>() ;
		try {
 		 st = con.createStatement();
	     rs = st.executeQuery("select * from book");
	     while(rs.next()){
	    	  Book p = new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
	    			  rs.getDouble(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getInt(9));
			  list.add(p);            	   
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return list;
	}
	
	
	
	
}
