package com.book.BO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.book.bean.Book;
import com.book.bean.Student;
import com.book.util.DBConn;
public class StudentBO {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement ps;
	public void updatePassword(String id, String pwd, String newpwd) {
		con = DBConn.getConn();
		try {
			 st = con.createStatement();
			 st.execute("update student set id='"+id+"',password='"+newpwd+"' where password ='"+pwd+"'");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
	}
	
	
	
}
