package com.book.BO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.book.bean.Administor;
import com.book.bean.Book;
import com.book.bean.Student;
import com.book.bean.Teacher;
import com.book.util.DBConn;

public class LoginBO {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement ps;
	public Student StuLogin(String id,String password){
		 con = DBConn.getConn();
		 Student stu= null;
		try {
			 st = con.createStatement();
			//ִ��sql
			 rs = st.executeQuery("select * from student where id='"+id+"' and password ='"+password+"'");
			//���������
			if(rs.next()){
				stu=new Student();
				stu.setId(rs.getString(1));
				stu.setUsername(rs.getString(2));
				stu.setPassword(rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return stu;
			}
	public Teacher TeaLogin(String id, String password) {
		con = DBConn.getConn();
		 Teacher tea= null;
		try {
			 st = con.createStatement();
			//ִ��sql
			 rs = st.executeQuery("select * from teacher where id='"+id+"' and password ='"+password+"'");
			//���������
			if(rs.next()){
				tea=new Teacher();
				tea.setId(rs.getString(1));
				tea.setUsername(rs.getString(2));
				tea.setPassword(rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return tea;
	}
	public Administor AdmLogin(String id, String password) {
		con = DBConn.getConn();
		Administor adm= null;
		try {
			 st = con.createStatement();
			 rs = st.executeQuery("select * from administor where id='"+id+"' and password ='"+password+"'");
			if(rs.next()){
				adm=new Administor();
				adm.setUsername(rs.getString(1));
				adm.setPassword(rs.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConn.close(rs, st, con);
		}
		return adm;
	}
}
