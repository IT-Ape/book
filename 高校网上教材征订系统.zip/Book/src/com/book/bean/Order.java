package com.book.bean;

public class Order {
	private int order_id;
	private int plan_id;
	private String delsoft;
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int orderId) {
		order_id = orderId;
	}
	public int getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(int planId) {
		plan_id = planId;
	}
	public String getDelsoft() {
		return delsoft;
	}
	public void setDelsoft(String delsoft) {
		this.delsoft = delsoft;
	}
	public Order(int orderId, int planId, String delsoft) {
		super();
		order_id = orderId;
		plan_id = planId;
		this.delsoft = delsoft;
	}
	public Order(int orderId, int planId) {
		super();
		order_id = orderId;
		plan_id = planId;
	}
	
	
}
