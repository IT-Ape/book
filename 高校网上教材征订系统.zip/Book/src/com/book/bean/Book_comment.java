package com.book.bean;

public class Book_comment {
	private String book_id;
	private String com_id;
	private String book_com_id;
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String bookId) {
		book_id = bookId;
	}
	public String getCom_id() {
		return com_id;
	}
	public void setCom_id(String comId) {
		com_id = comId;
	}
	public String getBook_com_id() {
		return book_com_id;
	}
	public void setBook_com_id(String bookComId) {
		book_com_id = bookComId;
	}
	public Book_comment(String bookId, String comId, String bookComId) {
		super();
		book_id = bookId;
		com_id = comId;
		book_com_id = bookComId;
	}
	public Book_comment() {
		super();
	}
	
}
