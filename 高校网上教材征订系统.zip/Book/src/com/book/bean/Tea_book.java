package com.book.bean;

public class Tea_book {
	private String tea_book_id;
	private String book_id;
	private String tea_id;
	private String term;
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getTea_book_id() {
		return tea_book_id;
	}
	public void setTea_book_id(String teaBookId) {
		tea_book_id = teaBookId;
	}
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String bookId) {
		book_id = bookId;
	}
	public String getTea_id() {
		return tea_id;
	}
	public void setTea_id(String teaId) {
		tea_id = teaId;
	}
	public Tea_book(String teaBookId, String bookId, String teaId,String term) {
		super();
		tea_book_id = teaBookId;
		book_id = bookId;
		tea_id = teaId;
		term=this.term;
	}
	public Tea_book() {
		super();
	}
	   
}
