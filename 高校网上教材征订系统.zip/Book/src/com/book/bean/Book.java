package com.book.bean;

public class Book {
	private String book_id;
	private String author;
	private String name;
	private String type;
	private double price;
	private String publisher;
	private String pubDate;
	private String introduce;
	private int quantity;
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String bookId) {
		book_id = bookId;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getPubDate() {
		return pubDate;
	}
	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}
	
	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public Book(String bookId, String author, String name, String type,
			double price, String publisher, String pubDate, String introduce) {
		super();
		book_id = bookId;
		this.author = author;
		this.name = name;
		this.type = type;
		this.price = price;
		this.publisher = publisher;
		this.pubDate = pubDate;
		this.introduce = introduce;
	}
	public Book(String bookId, String author, String name, String type,
			double price, String publisher, String pubDate) {
		super();
		book_id = bookId;
		this.author = author;
		this.name = name;
		this.type = type;
		this.price = price;
		this.publisher = publisher;
		this.pubDate = pubDate;
	}
	public Book(String bookId, String name, double price) {
		super();
		book_id = bookId;
		this.name = name;
		this.price = price;
	}
	public Book() {
		super();
	}
	public Book(String bookId, double price) {
		super();
		book_id = bookId;
		this.price = price;
	}
	public Book(String bookId, String author, String name, String type,
			double price, String publisher, String pubDate, String introduce,
			int quantity) {
		super();
		book_id = bookId;
		this.author = author;
		this.name = name;
		this.type = type;
		this.price = price;
		this.publisher = publisher;
		this.pubDate = pubDate;
		this.introduce = introduce;
		this.quantity = quantity;
	}
		
}
