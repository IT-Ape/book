package com.book.bean;

public class Stu_book {
	   private String stu_book_id;
	   private String book_id;
	   private String stu_id;
	   private String term;
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getStu_book_id() {
		return stu_book_id;
	}
	public void setStu_book_id(String stuBookId) {
		stu_book_id = stuBookId;
	}
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String bookId) {
		book_id = bookId;
	}
	public String getStu_id() {
		return stu_id;
	}
	public void setStu_id(String stuId) {
		stu_id = stuId;
	}
	public Stu_book(String stuBookId, String bookId, String stuId,String term) {
		super();
		stu_book_id = stuBookId;
		book_id = bookId;
		stu_id = stuId;
		term=this.term;
	}
	public Stu_book() {
		super();
	}
	   
}
