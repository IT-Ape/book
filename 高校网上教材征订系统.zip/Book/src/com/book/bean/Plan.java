package com.book.bean;

public class Plan {
	private String book_id;
	private String plan_id;
	private String tea_id;
	private String book_name;
	private String tea_name;
	private double price;
	private int number;
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String bookName) {
		book_name = bookName;
	}
	public String getTea_name() {
		return tea_name;
	}
	public void setTea_name(String teaName) {
		tea_name = teaName;
	}
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String bookId) {
		book_id = bookId;
	}
	public String getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(String planId) {
		plan_id = planId;
	}
	public String getTea_id() {
		return tea_id;
	}
	public void setTea_id(String teaId) {
		tea_id = teaId;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public Plan(String bookId, String planId, String teaId, int number) {
		super();
		book_id = bookId;
		plan_id = planId;
		tea_id = teaId;
		this.number = number;
	}
	public Plan(String bookId, String planId, String teaId) {
		super();
		book_id = bookId;
		plan_id = planId;
		tea_id = teaId;
	}
	
	public Plan(String bookId, String planId, String teaId, String bookName,
			String teaName, int number) {
		super();
		book_id = bookId;
		plan_id = planId;
		tea_id = teaId;
		book_name = bookName;
		tea_name = teaName;
		this.number = number;
	}
	public Plan(String bookId, String planId, String teaId, String bookName,
			String teaName, double price, int number) {
		super();
		book_id = bookId;
		plan_id = planId;
		tea_id = teaId;
		book_name = bookName;
		tea_name = teaName;
		this.price = price;
		this.number = number;
	}
	public Plan() {
		super();
	}
	
}
