package com.book.bean;

public class Comment {
	private String com_id;
	private String comment;
	public Comment(String comId, String comment) {
		super();
		com_id = comId;
		this.comment = comment;
	}
	public String getCom_id() {
		return com_id;
	}
	public void setCom_id(String comId) {
		com_id = comId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Comment() {
		super();
	}
	
	
}
